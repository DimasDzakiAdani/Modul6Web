<?php

// app/Http/Controllers/CarController.php
// app/Http/Controllers/CarController.php

// app/Http/Controllers/CarController.php

namespace App\Http\Controllers;

use App\Models\Car;
use Illuminate\Http\Request;

class CarController extends Controller
{
    public function index()
    {
        $cars = Car::all();
        return response()->json(['message' => 'success', 'data' => $cars], 200);
    }

    public function show($id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found', 'success' => false], 404);
        }

        return response()->json(['message' => 'success', 'data' => $car], 200);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'brand' => 'required',
            'model' => 'required',
            'year' => 'required|integer',
            'price' => 'required|numeric',
        ]);

        $car = Car::create($request->all());

        return response()->json(['message' => 'success', 'data' => $car], 201);
    }

    public function update(Request $request, $id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found', 'success' => false], 404);
        }

        $car->update($request->all());

        return response()->json(['message' => 'success', 'data' => $car], 200);
    }

    public function destroy($id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found', 'success' => false], 404);
        }

        $car->delete();

        return response()->json(['message' => 'success', 'data' => 'Car deleted'], 200);
    }
}
